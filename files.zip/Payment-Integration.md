# Payment Integration

Supported gateways
- Stripe (recommended)
- PayPal (Billing Agreements / Subscriptions)
- Adapter pattern to add more providers

Stripe setup (development)
1. Create a Stripe account and get test keys.
2. Set STRIPE_SECRET_KEY and STRIPE_PUBLISHABLE_KEY in .env.
3. Create webhook endpoint secret:
   - In the Stripe dashboard, add a webhook to https://<your-host>/webhooks/stripe and copy the signing secret to STRIPE_WEBHOOK_SECRET.
4. Use test card numbers (4242 4242 4242 4242) for dev testing.

Stripe best practices
- Verify signatures using the webhook signing secret.
- Use idempotency keys for create requests to avoid duplicate payments.
- Store only non-sensitive gateway identifiers; never store full card numbers or CVV.

Webhook handling
- Webhook endpoints:
  - /webhooks/stripe
  - /webhooks/paypal
- Validate signature, parse event, map to internal event types, and process idempotently.
- Acknowledge HTTP 200 quickly; push heavy work to background jobs.

Testing webhooks locally
- Use Stripe CLI or ngrok to forward events to your local server:
  stripe listen --forward-to localhost:3000/webhooks/stripe