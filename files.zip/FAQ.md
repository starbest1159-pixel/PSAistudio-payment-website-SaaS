# FAQ

Q: Which payment gateways are supported?
A: Stripe is the primary integration; PayPal is supported via an adapter. The system uses an adapter pattern so more gateways can be added.

Q: Is card data stored?
A: No. We only store gateway tokens/IDs. Always use the gateway's client-side tokenization.

Q: Can I run the project locally without Docker?
A: Yes, follow the Quickstart — you can run the DB remotely or use a local Postgres instance.

Q: How are webhooks secured?
A: Webhooks are verified using each gateway's signing secret. See Payment Integration for verification details.

Q: How do I change pricing for a plan?
A: Update the plan definition; decide proration behavior; then create a migration or admin change. Follow Billing & Plans guidance.