# Deployment

Deployment targets
- Docker Compose for self-hosted deployments
- Cloud platforms: Vercel/Netlify (frontend), Heroku/AWS/GCP (backend), Railway for full-stack
- Kubernetes manifests (if large-scale multi-tenant hosting is needed)

Environment variables
- Always set secrets in your host environment (DO NOT commit .env files).
- Minimum required environment variables for production:
  - NODE_ENV=production
  - PORT
  - DATABASE_URL
  - JWT_SECRET
  - STRIPE_SECRET_KEY
  - STRIPE_WEBHOOK_SECRET
  - OPTIONAL: REDIS_URL (for workers), SENTRY_DSN

Docker
- Build:
  docker build -t psaistudio-payment:latest .
- Run:
  docker run -e DATABASE_URL=... -p 3000:3000 psaistudio-payment:latest

CI/CD
- Recommended steps:
  - Run tests (unit + integration)
  - Run linting
  - Build and publish Docker image
  - Run migrations as part of release job