# Security

Sensitive data handling
- Do not store raw payment instrument data (card numbers, CVV).
- Use gateway tokens/IDs to reference payment methods.
- Encrypt secrets at rest and use environment variables or secrets managers (AWS Secrets Manager, Vault).

PCI & compliance
- If you handle card data directly, ensure PCI-DSS compliance; better approach is to use hosted checkout or tokenization via gateway SDKs.
- Use HTTPS everywhere; ensure TLS termination is secure.

Authentication & authorization
- Use JWTs or OAuth for API auth. Keep token expiry short for session tokens.
- Role-based access control for admin vs. merchant vs. customer actions.

Operational security
- Rotate keys periodically.
- Limit access to production credentials.
- Audit logs for critical operations (refunds, plan changes).
- Add rate limiting and bot protections for public endpoints.

Monitoring & incident response
- Integrate with Sentry / error-tracking.
- Monitor webhook failures and build retry logic.