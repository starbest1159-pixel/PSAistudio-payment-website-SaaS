# Quickstart

This page shows the minimal steps to run the project locally.

Prerequisites
- Node.js 18+ (or the version specified in .nvmrc)
- Docker (optional, recommended for DB)
- Yarn or npm
- Git

Clone repository
git clone https://github.com/starbest1159-pixel/PSAistudio-payment-website-SaaS.git
cd PSAistudio-payment-website-SaaS

Environment
- Copy .env.example to .env and fill required values:
  - PORT
  - DATABASE_URL (Postgres)
  - STRIPE_SECRET_KEY / STRIPE_PUBLISHABLE_KEY (test keys for development)
  - PAYPAL_CLIENT_ID / PAYPAL_SECRET (sandbox)
  - JWT_SECRET
  - WEBHOOK_SECRET

Run locally (node)
# Install
yarn install
# Start dev server
yarn dev

Run with Docker (recommended)
- Start Postgres:
  docker-compose up -d db
- Run the app:
  yarn docker:dev

Database migrations
- Run migrations and seeders if present:
  yarn db:migrate
  yarn db:seed

Useful commands
- yarn test — run unit & integration tests
- yarn lint — static checks
- yarn build — production build