# Billing & Plans

Concepts
- Plan: Definition of price/interval/limits (e.g., Free, Pro, Enterprise).
- Subscription: Active customer subscription to a plan.
- Invoice: Generated for billing cycles or one-time charges.

Plan management
- Plans are defined in configuration or in the database.
- Changes to plan pricing should trigger invoice/proration handling (see gateway docs).

Invoices & receipts
- Invoices are created on schedule (cron or background job).
- Send invoices and receipts via email (via SMTP provider).
- Provide customer portal to view invoice history and manage payment methods.

Proration and upgrades
- If a customer upgrades/downgrades mid-cycle, determine behavior:
  - Immediate proration: charge or credit remaining time.
  - Start new cycle: switch at next billing date.
- Follow your chosen gateway’s proration APIs for accurate billing.