# Roadmap

Planned features
- 1.0: Stable Stripe integration, subscriptions, customer portal
- 1.1: PayPal billing, advanced reporting, email receipts
- 1.2: Multi-tenant admin UI, tenant billing dashboards
- 2.0: Usage-based billing/metering, invoicing engine improvements
- Future: Marketplace features, plugin marketplace for gateway adapters

How to influence the roadmap
- Open feature requests as issues and tag them with "roadmap".
- Upvote or comment on issues to indicate priority.