# Contributing

We welcome contributions! Please follow these steps.

How to contribute
1. Fork the repo and create a branch: feat/your-feature or fix/issue-number
2. Run tests and linters locally.
3. Open a pull request describing the change and its rationale.

Code style
- Follow ESLint + Prettier config in the repo.
- Keep commits small and focused; use conventional commits if possible.

Testing
- Unit tests: run yarn test
- Integration tests: read tests/integration/README.md for requirements (may need test DB)
- Add tests for new functionality and bug fixes.

Branching & PRs
- Target branch: main (or as specified in repo)
- Include a descriptive PR title and link to any related issues.

Review process
- PRs will be reviewed by maintainers. Expect CI checks and reviewer feedback.