# Architecture Overview

High-level components
- Frontend: React (or Next.js) single-page app for customer interactions and admin dashboard.
- Backend: Node/Express (or Nest) API that handles authentication, payments, and webhooks.
- Database: PostgreSQL for persistent data (customers, subscriptions, invoices).
- Worker: Background job processor (Bull/Redis or Sidekiq-style) for async tasks (invoice generation, retries).
- Payment Gateways: Stripe (primary), PayPal (optional). Gateway adapters abstract provider specifics.
- Webhooks: Secure endpoint to receive events from gateways; idempotent processing.

Data flow
1. Customer initiates checkout in the frontend.
2. Frontend obtains checkout tokens from backend (or uses gateway-hosted checkout).
3. Gateway returns payment event; webhook posts back to the backend.
4. Backend validates webhook, updates subscription/invoice state, and enqueues follow-up jobs.

Multi-tenant considerations
- Tenant isolation via tenant_id fields + row-level scoping.
- Secrets and gateway keys can be per-tenant or shared depending on the offering.